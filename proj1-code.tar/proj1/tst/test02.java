// Single-line comment
/* Multi-line comments
 * this embedded /* is treated as part of comments
 * !@# $%^& *()_ +|~` \=-' :"; <> ,.?/ {}[] .. //
 * */
 * The end
 */

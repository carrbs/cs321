// testing integer limits

2147483647 // OK

2147483648 // overflow

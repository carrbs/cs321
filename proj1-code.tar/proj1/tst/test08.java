// testing illegal characters

* # _

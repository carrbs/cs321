// missing class name
class {
  public static void main(String[] a) {
    int x; 
  }
}

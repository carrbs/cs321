class testd25 {
  public static void main(String[] a) {
    while (1) a = true;   // OK
    while (true);
  }
}

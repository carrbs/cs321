class testd21 {
  public static void main(String[] a) {
    (1) = 100;  // invalid lhs
  }
}

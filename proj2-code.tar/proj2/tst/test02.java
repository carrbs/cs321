// test simple decls
// (should print 1, 2, 6)
class test {
  public static void main(String[] a) {
    boolean b;
    int i;
    int j;
    b = true;
    i = 1 + 1;
    j = 3 * i;
    System.out.println(b);
    System.out.println(i);
    System.out.println(j);
  }
}

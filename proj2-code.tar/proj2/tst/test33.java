// test outputs on statements
//
class test {
  public static void main(String[] a) {
    int i = 2;
    int j = 3;
    int k = i+j;
    System.out.println(k); 
    if (k==5) System.out.println("OK");
  }
}


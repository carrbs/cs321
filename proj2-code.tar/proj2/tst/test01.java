// test simple output
// (should print "123", 123, , 1)
class test {
  public static void main(String[] a) {
    System.out.println("123");
    System.out.println(123);
    System.out.println();
    System.out.println(true);
  }
}

// operator error
class testd19 {
  public static void main(String[] a) {
    x = new int[3].length();
  }
}

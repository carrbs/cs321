// keywords 'void' and 'static' out of order
class testd05 {
  public void static main(String[] a) { }
}

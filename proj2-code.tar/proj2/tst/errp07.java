// can't declare two variables in one line
class testd07 {
  public static void main(String[] a) {
    int x, y;
  }
}

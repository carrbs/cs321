// wrong syntax at ','
class testd11 {
  public static void main(String[] a) {
    int i,
    double d;
  }
}

// declaration at wrong place
class testd08 {
  public static void main(String[] a) {
    x = 1;
    int x;
  }
}

// missing keyword 'void'
class testd02 {
  public static main(String[] a) {
    int x;
  }
}

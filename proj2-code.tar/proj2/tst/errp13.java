// wrong argument
class testd13 {
  public static void main(String[] a) {
    System.out.println("result:" + a);
  }
}
